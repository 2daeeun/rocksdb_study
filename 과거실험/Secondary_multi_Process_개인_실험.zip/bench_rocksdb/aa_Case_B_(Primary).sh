./db_bench --benchmarks="overwrite,stats" \
  --db=/home/leedaeeun/bench_rocksdb/fill_data_1M \
  --use_existing_db=true \
  --num=100000 \
  --disable_wal=0 \
  --statistics \
  --value_size=4096 \
  --histogram=true
